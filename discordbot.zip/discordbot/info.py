key="your key here"
username_id:int = 0#update this with your user id
channel_id:int = 0#update this with your channel id
username='your username here'



token = {
    
    'key': key,
    'username_id':username_id,
    'channel_id':channel_id, 
    'username':username
    
}