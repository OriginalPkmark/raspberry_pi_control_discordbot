import subprocess
import os
import time



temperature_threshold = 90.0

def get_temperature():
    output = subprocess.check_output(["vcgencmd", "measure_temp"]).decode() 
    cpu = output.split('=')[1].split("'")[0]
    print(f"Current CPU temperature: {cpu:.2f}°C ❄️🤔")
    return cpu


def c_temp():
    while True:
        temperature = get_temperature()
        print(f"Current temperature: {temperature}°C")

        if temperature > temperature_threshold:
            os.system("sudo shutdown now")
        
        time.sleep(10)