from info import token
import discord
from discord import app_commands
from discord.ext import commands
from functions import get_temperature, check_internet_speed,  methods_d, break_pi
import asyncio


def run():
    bot.run(token['key'])
    

bot = commands.Bot(command_prefix="!", intents=discord.Intents.all())

#this where the commands are listed at
@bot.tree.command(name='help', description="for commands for details on the other commands")
async def help(interaction: discord.Interaction):
    print(f"user: {interaction.user} , ")
    if interaction.user.name == token['username'] or interaction.user.id == token['username_id']: 
        
            response = "Here is what I can do:\n"
            # Iterating over items() method
            for command, description in methods_d.items():
                response += f"command: {command}:\n {description}\n \n"
                print(f"Command: {command}, Description: {description}")
                
            print(response)
            await interaction.response.send_message(response)    
        
    else:
            await interaction.response.send_message(f"are you the owner of the pi {interaction.user} please don't message me if you are not the owner ")
            
                
@bot.tree.command(name='shut_down', description="will turn off the pi")
@app_commands.describe(are_sure="just to make sure you want to turn the pi off say (Yes/no)")
async def shut_down(interaction: discord.Interaction,are_sure: str):
    print(f"user: {interaction.user}, {interaction.message}")
    if interaction.user == token['username'] or token['username_id']:
        if are_sure == 'Yes':
            try:
                breaks = break_pi()
                print(breaks)
                await interaction.response.send_message(breaks)
            except Exception as e:
                print(e)
        else:
            await interaction.response.send_message(f'ok will no shut down the pi {interaction.user}')
    
    else:
        await interaction.response.send_message(f"i don't known who you are {interaction.user} please don't message,me again ")
        


@bot.tree.command(name="hello")
@app_commands.describe(thing_to_say="what you want me to say to you")

#this is the command that will be used to test the bot
async def hello(interaction: discord.Interaction, thing_to_say: str): # Added 'thing_to_say' parameter
    if interaction.user == token['username'] or token['username_id']:
        await interaction.response.send_message(f"hehehehe {interaction.user} said {thing_to_say}")
    else:
        await interaction.response.send_message(f"who are you {interaction.user}, why are you messaging me, don't message again")
        print(f'user called {interaction.user} tried to use bot')



@bot.tree.command(name='internet_speed', description='Checks the internet speed of the Pi')
async def internet_speed(interaction: discord.Interaction):
    if interaction.user.id == token['username_id']:  # Assuming token['username_id'] is an integer
        await interaction.response.defer()  # Acknowledge the interaction
        print("checking the internet speed")
        try:
            download_speed, upload_speed = check_internet_speed()
            print(f"Download: {download_speed} Upload: {upload_speed} for the Pi")

            if download_speed > 50 and upload_speed > 10:
                response = f"Great speeds!!!! Download: {download_speed:.2f} Mbps, Upload: {upload_speed:.2f} Mbps 🚀"
            elif download_speed > 20 and upload_speed > 5:
                response = f"Decent speeds!!!!! Download: {download_speed:.2f} Mbps, Upload: {upload_speed:.2f} Mbps 🌐"
            else:
                response = "Consider checking your internet connection. ❓"

            await interaction.followup.send(response)
        
        except Exception as e:
            print(f"Error: {e}")
            if not interaction.response.is_done():
                await interaction.followup.send(f"An error occurred: {e}")

    else:
        await interaction.response.send_message(f"Who are you {interaction.user}, why are you messaging me? Don't message again.")
        print(f"User {interaction.user} tried to use the bot but is not authorized.")




@bot.tree.command(name='temp',description='will get the pi temps for you')
async def temp(interaction: discord.Integration):
    if interaction.user == token['username'] or token['username_id']:
        await interaction.response.defer()
        print("getting the temp for the pi")
        try:
        
            temp = get_temperature()
            print(f"{temp}")
            await interaction.followup.send(temp)
            
        except Exception as e:
            print(e)
    else:
        await interaction.response.send_message(f"who are you {interaction.user}, why are you messaging me, don't message again")
        print(f'user called {interaction.user} tried to use bot')



# sync the bot up and add the commands on ready

@bot.event
async def on_ready():
    print(f"'{bot.user} has connected to Discord!'")
    
    try:
        synced = await bot.tree.sync()
        print(f"Synced with commands {len(synced)}")
    except Exception as e:
        print(e)



@bot.event
async def on_message(message):
    print(message)
    # Prevent the bot from responding to its own messages
    if message.author == bot.user:
        return

    await message.channel.send('try using a slash commands bc the building message system is not ready yet to use')   
run()
