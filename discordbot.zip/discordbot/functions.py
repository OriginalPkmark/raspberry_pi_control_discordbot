import subprocess
import speedtest



def get_temperature():
    output = subprocess.check_output(["vcgencmd", "measure_temp"]).decode() 
    new_output = float(output.split('=')[1].split("'")[0])
    response = f"Current CPU temperature: {new_output:.2f}°C ❄️🤔"
    return response



def check_internet_speed():
    st = speedtest.Speedtest()
    download_speed = st.download() / 1_000_000  # Convert to Mbps
    upload_speed = st.upload() / 1_000_000  # Convert to Mbps
    

    return download_speed, upload_speed



def break_pi():
    try:
            subprocess.run(["sudo", "shutdown", "now"], check=True)
            response = "Shutting down the Raspberry Pi. Goodbye! 👋🚀"
    except subprocess.CalledProcessError as e:
            response = f"Failed to shut down the Raspberry Pi. Error: {e} ❌"
    except Exception as e:
            response = f"An unexpected error occurred: {e} ❌"
    
    return response
    


#make sure you update the hash map so that methods can work
# ITS  for the !help command
methods_d = {
    'temp': 'will run get_temperature() that will get the current temperature',
    'internet_speed' : 'runs check_internet_speed() which will get the internet speed on the pi',
    'shut_down' : 'will run the break_pi() which will shut down the pi',
    'help': 'it will tell you what commands i have'
    
}