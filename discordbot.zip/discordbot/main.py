import threading
import temp
import messages



    
temp_thread = threading.Thread(target=temp.c_temp)
temp_thread.start()

messages.run_bot()
    